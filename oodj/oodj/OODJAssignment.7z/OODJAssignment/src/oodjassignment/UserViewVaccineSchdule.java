/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oodjassignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Kriso
 */
public class UserViewVaccineSchdule extends javax.swing.JFrame {

    /**
     * Creates new form UserViewVaccineSchdule
     */
    public String UserID;
    public String Dose1;
    public String Dose2;
    public String Text = "User.txt";
    public String Text1 = "VaccineAppointment.txt";
    public String Text2 = "VaccineCenter.txt";
    public String Delimeter = "@#;";


   public UserViewVaccineSchdule(String UID) {
        initComponents();
        this.UserID = UID;
        int AppointmentStatus = 0;
        String UserName = null;
        try {
            File Flist = new File(Text);
            Scanner sc1 = new Scanner(Flist);
            while (sc1.hasNextLine()) {
                String Line = sc1.nextLine();
                if (Line.contains(UserID)) {
                    String[] wordsinLine = Line.split(Delimeter);
                    UserName = wordsinLine[1];
                    Dose1 = wordsinLine[12];
                    Dose2 = wordsinLine[13];
                    AppointmentStatus = Integer.parseInt(wordsinLine[11]);
                }
            }
            sc1.close();
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
        LblUVIC.setText(UserID);
        LblUVName.setText(UserName);

        String CenterName = null;
        String CenterAddress = null;
        String CenterID = null;
        String Dose = null;
        String DoseDate = null;
        

        if (!Dose1.equals("null") && Dose2.equals("null")) {
            try {
                File Flist = new File(Text1);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(Dose1)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        CenterID = wordsinLine[3];
                        Dose = wordsinLine[4];
                        DoseDate = wordsinLine[5];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
            try {
                File Flist = new File(Text2);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(CenterID)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        CenterName = wordsinLine[1];
                        CenterAddress = wordsinLine[2];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }

            UserView View = new UserView();
            View.setAddress(CenterAddress);
            View.setCenterName(CenterName);
            View.setDose(Dose);
            View.setDoseDate(DoseDate);
            View.setDose1(Dose1);
            View.setDose2(Dose2);
            View.setAppointmentStatus(AppointmentStatus);

            View.ViewSchdule(JTXTDose1, JTXTDose2);

            if (AppointmentStatus == 1) {
                this.BtnConfirmAppointment.setEnabled(true);
                this.BtnCancleAppointment.setEnabled(true);
            } else {
                this.BtnConfirmAppointment.setEnabled(false);
                this.BtnCancleAppointment.setEnabled(false);
            }
        } else if (!Dose1.equals("null") && !Dose2.equals("null")) {
            try {
                File Flist = new File(Text1);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(Dose2)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        CenterID = wordsinLine[3];
                        Dose = wordsinLine[4];
                        DoseDate = wordsinLine[5];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
            try {
                File Flist = new File(Text2);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(CenterID)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        CenterName = wordsinLine[1];
                        CenterAddress = wordsinLine[2];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }

            UserView View = new UserView();
            View.setAddress(CenterAddress);
            View.setCenterName(CenterName);
            View.setDose(Dose);
            View.setDoseDate(DoseDate);
            View.setAppointmentStatus(AppointmentStatus);
            View.setDose1(Dose1);
            View.setDose2(Dose2);

            View.ViewSchdule(JTXTDose1, JTXTDose2);

            if (AppointmentStatus == 1) {
                this.BtnConfirmAppointment.setEnabled(true);
                this.BtnCancleAppointment.setEnabled(true);
            } else {
                this.BtnConfirmAppointment.setEnabled(false);
                this.BtnCancleAppointment.setEnabled(false);
            }
        }
        else 
        {
                    AppointmentStatus = 3;
                    UserView View = new UserView();
                    View.setAppointmentStatus(AppointmentStatus);
                    View.setDose1(Dose1);
                    View.setDose2(Dose2);
                    View.ViewSchdule(JTXTDose1, JTXTDose2);

                    if (AppointmentStatus == 1) {
                        this.BtnConfirmAppointment.setEnabled(true);
                        this.BtnCancleAppointment.setEnabled(true);
                    } else {
                        this.BtnConfirmAppointment.setEnabled(false);
                        this.BtnCancleAppointment.setEnabled(false);
                    }
        }

    }

    private UserViewVaccineSchdule() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LblUVName = new javax.swing.JLabel();
        LblUVIC = new javax.swing.JLabel();
        LblUVS = new javax.swing.JLabel();
        LblUVS1 = new javax.swing.JLabel();
        BtnConfirmAppointment = new javax.swing.JButton();
        BtnCancleAppointment = new javax.swing.JButton();
        LblDose3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTXTDose1 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        JTXTDose2 = new javax.swing.JTextArea();
        BtnBack = new javax.swing.JButton();
        LblUVS2 = new javax.swing.JLabel();
        LblUVS3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        LblUVName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        LblUVIC.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        LblUVS.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblUVS.setText("Dose 1 :");

        LblUVS1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblUVS1.setText("Dose 2 :");

        BtnConfirmAppointment.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        BtnConfirmAppointment.setText("Confirm");
        BtnConfirmAppointment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnConfirmAppointmentActionPerformed(evt);
            }
        });

        BtnCancleAppointment.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        BtnCancleAppointment.setText("Cancle");
        BtnCancleAppointment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCancleAppointmentActionPerformed(evt);
            }
        });

        JTXTDose1.setEditable(false);
        JTXTDose1.setColumns(20);
        JTXTDose1.setRows(4);
        jScrollPane1.setViewportView(JTXTDose1);

        JTXTDose2.setEditable(false);
        JTXTDose2.setColumns(20);
        JTXTDose2.setRows(4);
        jScrollPane3.setViewportView(JTXTDose2);

        BtnBack.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        BtnBack.setText("Back");
        BtnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBackActionPerformed(evt);
            }
        });

        LblUVS2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblUVS2.setText("IC/Passport:");

        LblUVS3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblUVS3.setText("Name:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(389, 389, 389)
                .addComponent(BtnCancleAppointment, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(LblDose3, javax.swing.GroupLayout.DEFAULT_SIZE, 10, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(LblUVS)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 515, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(LblUVS1)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BtnConfirmAppointment, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 515, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(BtnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(131, 131, 131)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(LblUVS2)
                            .addComponent(LblUVS3, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(LblUVIC, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(22, 22, 22)
                                .addComponent(LblUVName, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(BtnBack)
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(LblUVS3)
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(LblUVName, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LblUVS2))
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LblUVS)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LblUVS1)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addComponent(LblDose3, javax.swing.GroupLayout.DEFAULT_SIZE, 7, Short.MAX_VALUE)
                                .addGap(40, 40, 40))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(BtnCancleAppointment)
                                    .addComponent(BtnConfirmAppointment))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(LblUVIC, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnConfirmAppointmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnConfirmAppointmentActionPerformed
        String UserName = null;
        String UserIC = null;
        int UserClicked = 0;
        int UserType = 0;
        int UserAge = 0;
        String UserPhone = null;
        String UserDOB = null;
        String UserPassword = null;
        String UserAddress = null;
        String UserState = null;
        String UserCountry = null;
        String CenterID = null;
        String VaccineType = null;
        String AppointmentDate = null;
        int AppointmentStatus = 2;
        
         if (!Dose1.equals("null") && Dose2.equals("null")) {
        try {
            File Flist = new File(Text);
            Scanner sc1 = new Scanner(Flist);
            while (sc1.hasNextLine()) {
                String Line = sc1.nextLine();
                if (Line.contains(UserID)&&Line.contains(Dose1)) {
                    String[] wordsinLine = Line.split(Delimeter);
                    UserName = wordsinLine[1];
                    UserIC = wordsinLine[2];
                    UserAge = Integer.parseInt(wordsinLine[3]);
                    UserPhone = wordsinLine[4];
                    UserDOB = wordsinLine[5];
                    UserPassword = wordsinLine[6];
                    UserCountry = wordsinLine[7];
                    UserAddress = wordsinLine[8];
                    UserState = wordsinLine[9];
                    UserType = Integer.parseInt(wordsinLine[10]);
                    UserClicked = Integer.parseInt(wordsinLine[14]);
                }
            }
            sc1.close();
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
        
        Register update = new Register(UserID,UserName,UserIC,UserAge,UserPhone,UserDOB,UserPassword,UserCountry,UserAddress,UserState,UserType,AppointmentStatus,Dose1,Dose2,UserClicked);
        if(update.Userupdate())
        {
        System.out.println("User data update sucessfully");
        }
        
                try {
                File Flist = new File(Text1);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(Dose1)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        
                        CenterID = wordsinLine[3];
                        VaccineType = wordsinLine[4];
                        AppointmentDate = wordsinLine[5];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
                
                VaccineAppointment Assign = new VaccineAppointment(Dose1, UserID,UserName,CenterID,VaccineType,AppointmentDate,AppointmentStatus);
                
                if(Assign.AssignAppointment())
                {
                    JOptionPane.showMessageDialog(null, "Appointmnet Accpeted sucessfully"); 
                    this.setVisible(false);
                    new UserViewVaccineSchdule(UserID).setVisible(true);
                }
         } 
         else if (!Dose1.equals("null") && !Dose2.equals("null")) {
        try {
            File Flist = new File(Text);
            Scanner sc1 = new Scanner(Flist);
            while (sc1.hasNextLine()) {
                String Line = sc1.nextLine();
                if (Line.contains(UserID)&&Line.contains(Dose1)) {
                    String[] wordsinLine = Line.split(Delimeter);
                    UserName = wordsinLine[1];
                    UserIC = wordsinLine[2];
                    UserAge = Integer.parseInt(wordsinLine[3]);
                    UserPhone = wordsinLine[4];
                    UserDOB = wordsinLine[5];
                    UserPassword = wordsinLine[6];
                    UserCountry = wordsinLine[7];
                    UserAddress = wordsinLine[8];
                    UserState = wordsinLine[9];
                    UserType = Integer.parseInt(wordsinLine[10]);
                    UserClicked = Integer.parseInt(wordsinLine[14]);
                }
            }
            sc1.close();
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
        
        Register update = new Register(UserID,UserName,UserIC,UserAge,UserPhone,UserDOB,UserPassword,UserCountry,UserAddress,UserState,UserType,AppointmentStatus,Dose1,Dose1,UserClicked);
        if(update.Userupdate())
        {
        System.out.println("User data update sucessfully");
        }
        
                try {
                File Flist = new File(Text1);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(Dose2)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        
                        CenterID = wordsinLine[3];
                        VaccineType = wordsinLine[4];
                        AppointmentDate = wordsinLine[5];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
                
                VaccineAppointment Assign = new VaccineAppointment(Dose2, UserID,UserName,CenterID,VaccineType,AppointmentDate,AppointmentStatus);
                
                if(Assign.AssignAppointment())
                {
                    JOptionPane.showMessageDialog(null, "Appointmnet Accpeted sucessfully"); 
                    this.setVisible(false);
                    new UserViewVaccineSchdule(UserID).setVisible(true);
                }
         } 
    }//GEN-LAST:event_BtnConfirmAppointmentActionPerformed

    private void BtnCancleAppointmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCancleAppointmentActionPerformed
 String UserName = null;
        String UserIC = null;
        int UserClicked = 0;
        int UserType = 0;
        int UserAge = 0;
        String UserPhone = null;
        String UserDOB = null;
        String UserPassword = null;
        String UserAddress = null;
        String UserState = null;
        String UserCountry = null;
        String CenterID = null;
        String VaccineType = null;
        String AppointmentDate = null;
        int AppointmentStatus = 3;
        
         if (!Dose1.equals("null") && Dose2.equals("null")) {
        try {
            File Flist = new File(Text);
            Scanner sc1 = new Scanner(Flist);
            while (sc1.hasNextLine()) {
                String Line = sc1.nextLine();
                if (Line.contains(UserID)&&Line.contains(Dose1)) {
                    String[] wordsinLine = Line.split(Delimeter);
                    UserName = wordsinLine[1];
                    UserIC = wordsinLine[2];
                    UserAge = Integer.parseInt(wordsinLine[3]);
                    UserPhone = wordsinLine[4];
                    UserDOB = wordsinLine[5];
                    UserPassword = wordsinLine[6];
                    UserCountry = wordsinLine[7];
                    UserAddress = wordsinLine[8];
                    UserState = wordsinLine[9];
                    UserType = Integer.parseInt(wordsinLine[10]);
                    UserClicked = Integer.parseInt(wordsinLine[14]);
                }
            }
            sc1.close();
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
        
        Register update = new Register(UserID,UserName,UserIC,UserAge,UserPhone,UserDOB,UserPassword,UserCountry,UserAddress,UserState,UserType,AppointmentStatus,"null","null",UserClicked);
        if(update.Userupdate())
        {
        System.out.println("User data update sucessfully");
        }
        
                try {
                File Flist = new File(Text1);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(Dose1)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        
                        CenterID = wordsinLine[3];
                        VaccineType = wordsinLine[4];
                        AppointmentDate = wordsinLine[5];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
                
                VaccineAppointment Assign = new VaccineAppointment(Dose1, UserID,UserName,CenterID,VaccineType,AppointmentDate,AppointmentStatus);
                
                if(Assign.AssignAppointment())
                {
                    JOptionPane.showMessageDialog(null, "Appointmnet Cancle sucessfully"); 
                    this.setVisible(false);
                    new UserViewVaccineSchdule(UserID).setVisible(true);
                }
         } 
         else if (!Dose1.equals("null") && !Dose2.equals("null")) {
        try {
            File Flist = new File(Text);
            Scanner sc1 = new Scanner(Flist);
            while (sc1.hasNextLine()) {
                String Line = sc1.nextLine();
                if (Line.contains(UserID)&&Line.contains(Dose1)&&Line.contains(Dose2)) {
                    String[] wordsinLine = Line.split(Delimeter);
                    UserName = wordsinLine[1];
                    UserIC = wordsinLine[2];
                    UserAge = Integer.parseInt(wordsinLine[3]);
                    UserPhone = wordsinLine[4];
                    UserDOB = wordsinLine[5];
                    UserPassword = wordsinLine[6];
                    UserCountry = wordsinLine[7];
                    UserAddress = wordsinLine[8];
                    UserState = wordsinLine[9];
                    UserType = Integer.parseInt(wordsinLine[10]);
                    UserClicked = Integer.parseInt(wordsinLine[14]);
                }
            }
            sc1.close();
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
        
        Register update = new Register(UserID,UserName,UserIC,UserAge,UserPhone,UserDOB,UserPassword,UserCountry,UserAddress,UserState,UserType,AppointmentStatus,Dose1,"null",UserClicked);
        if(update.Userupdate())
        {
        System.out.println("User data update sucessfully");
        }
        
                try {
                File Flist = new File(Text1);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(Dose2)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        
                        CenterID = wordsinLine[3];
                        VaccineType = wordsinLine[4];
                        AppointmentDate = wordsinLine[5];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
                
                VaccineAppointment Assign = new VaccineAppointment(Dose2, UserID,UserName,CenterID,VaccineType,AppointmentDate,AppointmentStatus);
                
                if(Assign.AssignAppointment())
                {
                    JOptionPane.showMessageDialog(null, "Appointmnet Cancle sucessfully"); 
                    this.setVisible(false);
                    new UserViewVaccineSchdule(UserID).setVisible(true);
                }
         } 
    }//GEN-LAST:event_BtnCancleAppointmentActionPerformed

    private void BtnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBackActionPerformed
        this.setVisible(false);
        new UserMain(UserID).setVisible(true);
    }//GEN-LAST:event_BtnBackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserViewVaccineSchdule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserViewVaccineSchdule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserViewVaccineSchdule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserViewVaccineSchdule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserViewVaccineSchdule().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnBack;
    private javax.swing.JButton BtnCancleAppointment;
    private javax.swing.JButton BtnConfirmAppointment;
    private javax.swing.JTextArea JTXTDose1;
    private javax.swing.JTextArea JTXTDose2;
    public javax.swing.JLabel LblDose3;
    private javax.swing.JLabel LblUVIC;
    private javax.swing.JLabel LblUVName;
    private javax.swing.JLabel LblUVS;
    private javax.swing.JLabel LblUVS1;
    private javax.swing.JLabel LblUVS2;
    private javax.swing.JLabel LblUVS3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    // End of variables declaration//GEN-END:variables
}
