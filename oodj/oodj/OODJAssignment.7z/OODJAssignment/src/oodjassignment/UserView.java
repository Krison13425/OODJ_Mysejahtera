/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oodjassignment;

import javax.swing.JLabel;
import javax.swing.JTextArea;

/**
 *
 * @author Kriso
 */
public class UserView extends VaccineAppointment {
    public String dose1;
    public String dose2;
    
    


    void ViewSchdule(JTextArea JTXTDose1, JTextArea JTXTDose2) 
    {
     
        if(GetDose1().equals("null")&&GetDose2().equals("null"))
        {
            JTXTDose1.setText("In Progressing");
            JTXTDose2.setText("Please Register For a New Appointment");
        }
        
        if(!GetDose1().equals("null")&&GetDose2().equals("null"))
        {   
                if(GetAppointmentStatus()==0)
                {
                    JTXTDose1.setText("In Progressing");
                }
                else if(GetAppointmentStatus()==1||GetAppointmentStatus()==2)
                {
                   JTXTDose1.setText(

                                    "Center Name :"+ GetCenterName()+
                                    "\nCenter Address : " +GetCenterAddress()+
                                    "\nAppointment Date :" +GetDoseDate()+
                                    "\nVaccine Type :" +GetDose()
                                ); 
                   JTXTDose2.setText(

                                    "\n" +
                                    "\n" +
                                    "\n" +
                                    ""
                                ); 
                }
                else if(GetAppointmentStatus()==3)
                {
                   JTXTDose1.setText("Complete"); 
                   
                   JTXTDose2.setText("Please Register For a New Appointment For Dose 2"); 
                }
                else if(GetAppointmentStatus()==4)
                {
                   JTXTDose1.setText("Complete");
                   JTXTDose2.setText(

                                    "\n" +
                                    "\n" +
                                    "\n" +
                                    ""
                                ); 
                }
        }
        else if(!GetDose1().equals("null")&&!GetDose2().equals("null"))
        {   
            JTXTDose1.setText("Complete");
            
                if(GetAppointmentStatus()==0)
                {
                    JTXTDose2.setText("In Progressing");
                }
                else if(GetAppointmentStatus()==1||GetAppointmentStatus()==2)
                {
                   JTXTDose2.setText(

                                    "Center Name :"+ GetCenterName()+
                                    "\nCenter Address : " +GetCenterAddress()+
                                    "\nAppointment Date :" +GetDoseDate()+
                                    "\nVaccine Type :" +GetDose()
                                ); 
                }
                else if(GetAppointmentStatus()==4)
                {
                   JTXTDose2.setText("Complete");
                }
        }
        
    }
    void ViewVaccineCertification(JTextArea JTxtVC)
    {
    
        if(!GetDose1().equals("null")&& GetDose2().equals("null"))
        {
            JTxtVC.setText
        ("                                     "+GetUserName()+
         "\n                                    "+GetUserIC()+
         "\n Dose 1 :"+
         "\n Date   :"+ GetDoseDate()+
         "\n Dose Type :"+GetDose()+
         "\n Center Name :"+GetCenterName()+
         "\n Batch : "+GetVaccineBatchNumber()    
        );
        }
        if(!GetDose1().equals("null")&& !GetDose2().equals("null"))
        {
            JTxtVC.setText
        ("                                     "+GetUserName()+
         "\n                                    "+GetUserIC()+
         "\n Dose 1 :"+
         "\n Date   :"+ GetDoseDate()+
         "\n Dose Type :"+GetDose()+
         "\n Center Name :"+GetCenterName()+
         "\n Batch : "+GetVaccineBatchNumber()+
         "\n"+
         "\n Dose 2 :"+
         "\n Date   :"+ GetDoseDate2()+
         "\n Dose Type :"+GetDoseType2()+
         "\n Center Name :"+GetCenterName2()+
         "\n Batch : "+GetVaccineBatchNumber2()
        );   
        }
        
        if(!GetDose1().equals("null")&& !GetDose2().equals("null")&&GetAppointmentStatus()!= 4)
        {
            JTxtVC.setText
        ("                                     "+GetUserName()+
         "\n                                    "+GetUserIC()+
         "\n Dose 1 :"+
         "\n Date   :"+ GetDoseDate()+
         "\n Dose Type :"+GetDose()+
         "\n Center Name :"+GetCenterName()+
         "\n Batch : "+GetVaccineBatchNumber()
        );   
        }
        
        

        }
    
    

}