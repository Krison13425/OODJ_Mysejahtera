package oodjassignment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class VaccineAppointment extends AdminCenter {

    
 public String AppointmentID,UserID,UserName,CenterID,Dose,DoseDate;
 public int AppointmentStatus;
// Certivication Dose 2
public int AppointmentStatus2;
public String DoseType2,DoseDate2;
 
 public String Delimeter = "@#;";
 public String Text = "VaccineAppointment.txt";
 
VaccineAppointment(){

}
VaccineAppointment (String AID ,String UID,String UN,String CID,String D,String DD,int AStatus){
AppointmentID = AID;
UserID = UID;
UserName = UN;
CenterID = CID;
Dose = D;
DoseDate = DD;
AppointmentStatus = AStatus;
}
// Vaccine Schedule and Cerivication Dose 1
 public int GetAppointmentStatus()
{
    return AppointmentStatus ;
}
  public String GetDoseDate()
{
    return DoseDate ;
}
    public String GetDose()
{
    return Dose ;
}
    
  public void setAppointmentStatus (int AS)
{
        AppointmentStatus = AS;
}
 
  public void setDoseDate(String DD)
{
        DoseDate = DD;
}
  public void setDose(String D)
{
        Dose = D;
}

// Certivication Dose 2
  public String GetDoseDate2()
{
    return DoseDate2 ;
}
    public String GetDoseType2()
{
    return DoseType2 ;
}

 
  public void setDoseDate2(String DD)
{
        DoseDate2 = DD;
}
  public void setDoseType2(String D)
{
        DoseType2 = D;
}
 
public boolean RegistAppointment(){
boolean sucess = true;

    try{
        
            FileWriter fw = new FileWriter(Text,true);
            
            fw.write( 
                      this.AppointmentID + Delimeter+ 
                      this.UserID +Delimeter+ 
                      this.UserName +Delimeter+ 
                      this.CenterID +Delimeter+
                      this.Dose +Delimeter+ 
                      this.DoseDate +Delimeter+
                      this.AppointmentStatus + Delimeter);
            fw.write(System.getProperty("line.separator"));
            fw.close();
            
            
        } catch (IOException ex) {
            sucess = false;
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
    return sucess;
}

public boolean AssignAppointment(){
boolean sucess = true;
String tempFile = "Temp.txt";
String currentLine;
String data[];
    try
                {
                    FileWriter fw = new FileWriter(tempFile,true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter pw = new PrintWriter(bw);
                    
                    FileReader fr = new FileReader(Text);
                    BufferedReader br =new BufferedReader(fr);
                    
                     while ((currentLine = br.readLine()) != null) {
                        data = currentLine.split(Delimeter);
                        if (!(data[0].equals(AppointmentID))) {
                            pw.println(currentLine);
                        } else {
                            pw.println(
                                        this.AppointmentID + Delimeter+ 
                                        this.UserID +Delimeter+ 
                                        this.UserName +Delimeter+ 
                                        this.CenterID +Delimeter+
                                        this.Dose +Delimeter+ 
                                        this.DoseDate +Delimeter+
                                        this.AppointmentStatus + Delimeter
                                      );
                        }
                    }
                    pw.flush();
                    fr.close();
                    br.close();
                    fw.close();
                    pw.close();
                    bw.close();
   
                }
                catch (FileNotFoundException ex) {
           JOptionPane.showMessageDialog(null, "Error Occurred");
                
            }   catch (IOException ex) {
                    java.util.logging.Logger.getLogger(AdminAssignAppointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }
                File oldFile = new File (Text);
                File newFile = new File (tempFile);
            System.out.println(oldFile.exists());
                    if (oldFile.delete()) { 
                System.out.println("Deleted the file: " + oldFile.getName());
                } else {
                System.out.println("Failed to delete the file.");
                    }
                    
                   newFile.renameTo(new File(Text));

    return sucess;
}

}
