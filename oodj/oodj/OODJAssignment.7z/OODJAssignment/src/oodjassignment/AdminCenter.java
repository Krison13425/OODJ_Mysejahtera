package oodjassignment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AdminCenter extends Register {

    
 public String CenterID,CenterName,CenterAddress,VaccineType,VaccineBatchNumber,VaccineSuppliedDate;
 public int CenterAppointment,OnSoptVolume;
 // Vaccine Schdule Certivication Dose 1
 public String Address,Name;
 
 // Certivication Dose 2
public String VaccineBatchNumber2,Name2;
 
 public String Text = "VaccineCenter.txt";
 public String Text1 = "SuppliedVaccineHistory.txt";
 public String Delimeter = "@#;";


 AdminCenter()
 {
 
 }
AdminCenter (String CID,String CN,String CAdd,int CApp,String VType,String VBN,String VSD,int OSV){
CenterID = CID;
CenterName = CN; 
CenterAddress = CAdd;
CenterAppointment = CApp;
VaccineType = VType;
VaccineBatchNumber = VBN;
VaccineSuppliedDate = VSD;
OnSoptVolume = OSV;
}

// Vaccine Schdule Certivication Dose 1
 public String GetCenterName()
{
    return Name ;
}
  public String GetCenterAddress()
{
    return Address ;
}
    public String GetVaccineBatchNumber()
{
    return VaccineBatchNumber;
}
 public void setAddress (String Add)
{
        Address = Add;
}
  public void setCenterName (String N)
{
        Name = N;
}
  public void setVaccineBatchNumber (String num)
{
        VaccineBatchNumber=num;
}

// Vaccine Schdule Certivication Dose 2
    public String GetCenterName2()
{
    return Name2 ;
}
    public String GetVaccineBatchNumber2()
{
    return VaccineBatchNumber2;
}
  public void setCenterName2 (String N)
{
        Name2 = N;
}
  public void setVaccineBatchNumber2 (String num)
{
        VaccineBatchNumber2=num;
}
  
    
public boolean AddVaccineCenter(){
boolean sucess = true;

    try{

            FileWriter fw = new FileWriter(Text,true);
            fw.write( this.CenterID +Delimeter+ 
                      this.CenterName +Delimeter+ 
                      this.CenterAddress +Delimeter+ 
                      this.CenterAppointment +Delimeter+ 
                      this.VaccineType +Delimeter+ 
                      this.VaccineBatchNumber +Delimeter+ 
                      this.VaccineSuppliedDate +Delimeter+
                      this.OnSoptVolume +Delimeter
                     );
            fw.write(System.getProperty("line.separator"));
            fw.close();
            
            
        } catch (IOException ex) {
            sucess = false;
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
    return sucess;
}


public boolean AddVaccineHistory(){
boolean sucess = true;

    try{

            FileWriter fw = new FileWriter(Text1,true);
            fw.write( this.CenterID +Delimeter+ 
                      this.CenterName +Delimeter+ 
                      this.CenterAddress +Delimeter+ 
                      this.CenterAppointment +Delimeter+ 
                      this.VaccineType +Delimeter+ 
                      this.VaccineBatchNumber +Delimeter+
                      this.VaccineSuppliedDate +Delimeter+
                      this.OnSoptVolume +Delimeter
                     );
            fw.write(System.getProperty("line.separator"));
            fw.close();
            
            
        } catch (IOException ex) {
            sucess = false;
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
    return sucess;
}

public boolean SupplyVaccine(){
boolean sucess = true;

String tempFile = "Temp.txt";     
String currentLine;
String data[];

    try
                {
                   

                    FileWriter fw = new FileWriter(tempFile,true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter pw = new PrintWriter(bw);
                    
                    FileReader fr = new FileReader(Text);
                    BufferedReader br =new BufferedReader(fr);
                    
                     while ((currentLine = br.readLine()) != null) {
                        data = currentLine.split(Delimeter);
                        if (!(data[0].equals(CenterID))) {
                            pw.println(currentLine);
                        } else {
                            pw.println(this.CenterID +Delimeter+ 
                                       this.CenterName +Delimeter+ 
                                       this.CenterAddress +Delimeter+ 
                                       this.CenterAppointment +Delimeter+ 
                                       this.VaccineType +Delimeter+ 
                                       this.VaccineBatchNumber +Delimeter+
                                       this.VaccineSuppliedDate +Delimeter+
                                       this.OnSoptVolume +Delimeter
                            );
                        }
                    }
                    pw.flush();
                    fr.close();
                    br.close();
                    fw.close();
                    pw.close();
                    bw.close();
   
                }
                catch (FileNotFoundException ex) {
           JOptionPane.showMessageDialog(null, "Error Occurred");
                
            }   catch (IOException ex) {
                    java.util.logging.Logger.getLogger(AdminSuppliedVaccine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                    sucess = false;
                }
                File oldFile = new File (Text);
                File newFile = new File (tempFile);
            System.out.println(oldFile.exists());
                    if (oldFile.delete()) { 
                System.out.println("Deleted the file: " + oldFile.getName());
                } else {
                System.out.println("Failed to delete the file.");
                    }
                   newFile.renameTo(new File(Text)); 
    return sucess;
}


public boolean DeleteVaccineCenter(){
boolean sucess = true;

                
                String tempFile = "Temp.txt";
                String currentLine;
                String data[];
                try
                {
                    FileWriter fw = new FileWriter(tempFile,true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter pw = new PrintWriter(bw);
                    
                    FileReader fr = new FileReader(Text);
                    BufferedReader br =new BufferedReader(fr);
                    
                    while((currentLine = br.readLine())!= null)
                    
                    {
                    data = currentLine.split(Delimeter);
                    if(!(data[0].equalsIgnoreCase(this.CenterID)))
                    {
                        pw.println(currentLine);
                    }
                    }
                    pw.flush();
                    fr.close();
                    br.close();
                    fw.close();
                    pw.close();
                    bw.close();
   
                }
                catch (FileNotFoundException ex) {
           JOptionPane.showMessageDialog(null, "Error Occurred");
                
            }   catch (IOException ex) {
                    java.util.logging.Logger.getLogger(AdminCenter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }
                File oldFile = new File (Text);
                File newFile = new File (tempFile);
            System.out.println(oldFile.exists());
                    if (oldFile.delete()) { 
                System.out.println("Deleted the file: " + oldFile.getName());
                } else {
                System.out.println("Failed to delete the file.");
                    }
                    
                   newFile.renameTo(new File(Text));
            
    
    return sucess;
}
}
