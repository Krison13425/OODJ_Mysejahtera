/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oodjassignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Kriso
 */
public class AdminViewUserProfiileDetials extends javax.swing.JFrame {

    /**
     * Creates new form CenterViewUserVaccineStatus
     */
    
    public String UserID;
    public String CenterID;
    public String Text = "User.txt";
    public String VAText = "VaccineAppointment.txt";
    public String CenterText = "VaccineCenter.txt";
    public String SVHText = "SuppliedVaccineHistory.txt";
    public String Delimeter = "@#;";
    public AdminViewUserProfiileDetials() {
        initComponents();
    }

    AdminViewUserProfiileDetials(String UID,String CID) {
        this.CenterID = CID; 
        this.UserID = UID;
        initComponents();
        String UserName = null;
        String UserIC = null;
        String UserAge = null;
        String UserPhone = null;
        String UserDOB = null;
        String UserAddress = null;
        String UserState = null;
        String UserCountry = null;
        String Dose1 = null;
        String Dose2 = null;
        String Dose1Type = null;
        String Dose2Type = null;
        int AppointmentStatus = 0;
        
       try {
            File Flist = new File(Text);
            Scanner sc1 = new Scanner(Flist);
            while (sc1.hasNextLine()) {
                String Line = sc1.nextLine();
                if (Line.contains(UID)) {
                    String[] wordsinLine = Line.split(Delimeter);
                    UserName = wordsinLine[1];
                    UserIC = wordsinLine[2];
                    UserAge = wordsinLine[3];
                    UserPhone = wordsinLine[4];
                    UserDOB = wordsinLine[5];
                    UserCountry = wordsinLine[7];
                    UserAddress = wordsinLine[8];
                    UserState = wordsinLine[9];
                    Dose1 = wordsinLine[12];
                    Dose2 = wordsinLine[13];
                    AppointmentStatus = Integer.parseInt(wordsinLine[11]);
                }
            }
            sc1.close();
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
       
       TxtUN.setText(UserName);
       TxtUIC.setText(UserIC);
       TxtPN.setText(UserPhone);
       TxtAge.setText(UserAge);
       TxtDOB.setText(UserDOB);
       TxtAdd.setText(UserAddress);
       TxtState.setText(UserState);
       TxtCountry.setText(UserCountry);
       
       
       try {
            File Flist = new File(VAText);
            Scanner sc1 = new Scanner(Flist);
            while (sc1.hasNextLine()) {
                String Line = sc1.nextLine();
                if (Line.contains(Dose1)) {
                    String[] wordsinLine = Line.split(Delimeter);
                    Dose1Type = wordsinLine[4];
                }
            }
            sc1.close();
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
       
       try {
            File Flist = new File(VAText);
            Scanner sc1 = new Scanner(Flist);
            while (sc1.hasNextLine()) {
                String Line = sc1.nextLine();
                if (Line.contains(Dose2)) {
                    String[] wordsinLine = Line.split(Delimeter);
                    Dose2Type = wordsinLine[4];
                }
            }
            sc1.close();
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
       
       TxtDose1Type.setText(Dose1Type);
       TxtDose2Type.setText(Dose2Type);
        
       if(Dose1.equals("null")&&Dose2.equals("null"))
       {
           TxtDose1.setText("Appoinmnet Not Registered");
           TxtDose2.setText("Appoinmnet Not Registered");
       }
       if(!Dose1.equals("null")&&Dose2.equals("null")&&AppointmentStatus==0)
       {
           TxtDose1.setText("Pending Admin Assign Appointment");
           TxtDose2.setText("Appoinmnet Not Registered");

       }
       if(!Dose1.equals("null")&&Dose2.equals("null")&&AppointmentStatus==4)
       {
           TxtDose1.setText("Vaccinated");
           TxtDose2.setText("Appoinmnet Not Registered");

       }
       if(!Dose1.equals("null")&&Dose2.equals("null")&&AppointmentStatus==2||!Dose1.equals("null")&&Dose2.equals("null")&&AppointmentStatus==3)
       {
           TxtDose1.setText("Appointment Assigned");
           TxtDose2.setText("Appoinmnet Not Registered");

       }
       
       
         if(!Dose1.equals("null")&&!Dose2.equals("null")&&AppointmentStatus==4)
       {
           TxtDose1.setText("Vaccinated");
           TxtDose2.setText("Vaccinated");
       }
       if(!Dose1.equals("null")&&!Dose2.equals("null")&&AppointmentStatus==0)
       {
           TxtDose1.setText("Vaccinated");
           TxtDose2.setText("Pending Appointment Assigned");
 
       }
       if(!Dose1.equals("null")&&!Dose2.equals("null")&&AppointmentStatus==3)
       {
           TxtDose1.setText("Vaccinated");
           TxtDose2.setText("Appoinmnet Not Registered");

       }
       if(!Dose1.equals("null")&&!Dose2.equals("null")&&AppointmentStatus==2||!Dose1.equals("null")&&!Dose2.equals("null")&&AppointmentStatus==1)
       {
           TxtDose1.setText("Vaccinated");
           TxtDose2.setText("Appointment Assigned");
       }
       
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LblState = new javax.swing.JLabel();
        TxtAdd = new javax.swing.JTextField();
        LblPN = new javax.swing.JLabel();
        LblUIC = new javax.swing.JLabel();
        TxtPN = new javax.swing.JTextField();
        TxtUIC = new javax.swing.JTextField();
        LblAge = new javax.swing.JLabel();
        TxtUN = new javax.swing.JTextField();
        TxtAge = new javax.swing.JTextField();
        LblUName = new javax.swing.JLabel();
        TxtState = new javax.swing.JTextField();
        LblResgister = new javax.swing.JLabel();
        TxtCountry = new javax.swing.JTextField();
        LblDOB = new javax.swing.JLabel();
        TxtDOB = new javax.swing.JTextField();
        LblCountry = new javax.swing.JLabel();
        LblAdd = new javax.swing.JLabel();
        TxtDose1 = new javax.swing.JTextField();
        LblDose1 = new javax.swing.JLabel();
        TxtDose2 = new javax.swing.JTextField();
        LblDOse2 = new javax.swing.JLabel();
        BtnBack = new javax.swing.JButton();
        LblDose2Type = new javax.swing.JLabel();
        TxtDose2Type = new javax.swing.JTextField();
        LbDose1Type = new javax.swing.JLabel();
        TxtDose1Type = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        LblState.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblState.setText("State:");

        TxtAdd.setEditable(false);

        LblPN.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblPN.setText("Phone :");

        LblUIC.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblUIC.setText("IC/Passport:");

        TxtPN.setEditable(false);

        TxtUIC.setEditable(false);

        LblAge.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblAge.setText("Age :");

        TxtUN.setEditable(false);
        TxtUN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtUNActionPerformed(evt);
            }
        });

        TxtAge.setEditable(false);

        LblUName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblUName.setText("Full Name:");

        TxtState.setEditable(false);

        LblResgister.setFont(new java.awt.Font("Times New Roman", 0, 36)); // NOI18N
        LblResgister.setText("User Profile");

        TxtCountry.setEditable(false);

        LblDOB.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblDOB.setText("DOB:");

        TxtDOB.setEditable(false);

        LblCountry.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblCountry.setText("Nationality:");

        LblAdd.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblAdd.setText("Address:");

        TxtDose1.setEditable(false);

        LblDose1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblDose1.setText("Dose1:");

        TxtDose2.setEditable(false);

        LblDOse2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblDOse2.setText("Dose2:");

        BtnBack.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        BtnBack.setText("Back");
        BtnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBackActionPerformed(evt);
            }
        });

        LblDose2Type.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LblDose2Type.setText("Dose2 Type:");

        TxtDose2Type.setEditable(false);
        TxtDose2Type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtDose2TypeActionPerformed(evt);
            }
        });

        LbDose1Type.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        LbDose1Type.setText("Dose1 Type:");

        TxtDose1Type.setEditable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(LblUIC, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(LblPN, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(TxtPN)
                                    .addComponent(TxtUIC, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(LblDOB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(LblAge, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TxtAge, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TxtDOB, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(LblAdd)
                                    .addComponent(LblState)
                                    .addComponent(LblCountry))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TxtAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TxtState, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TxtCountry, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(LblDose1)
                                    .addComponent(LblDOse2))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TxtDose1, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TxtDose2, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(LbDose1Type)
                                    .addComponent(LblDose2Type))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TxtDose1Type, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TxtDose2Type, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(LblUName)
                                .addGap(18, 18, 18)
                                .addComponent(TxtUN, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(BtnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(165, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(LblResgister)
                .addGap(203, 203, 203))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(BtnBack)
                .addGap(12, 12, 12)
                .addComponent(LblResgister, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LblUName)
                    .addComponent(TxtUN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtUIC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LblUIC))
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtPN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LblPN))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtAge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LblAge))
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LblDOB)
                    .addComponent(TxtDOB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtAdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LblAdd))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtState, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LblState))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtCountry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LblCountry))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtDose1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LblDose1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtDose1Type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LbDose1Type))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TxtDose2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LblDOse2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TxtDose2Type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LblDose2Type))
                .addGap(42, 42, 42))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBackActionPerformed
        this.setVisible(false);
        AdminViewUserProfile User = new AdminViewUserProfile();
        User.setVisible(true);
        User.pack();
        User.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        User.CenterID = CenterID;
    }//GEN-LAST:event_BtnBackActionPerformed

    private void TxtUNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtUNActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtUNActionPerformed

    private void TxtDose2TypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtDose2TypeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtDose2TypeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminViewUserProfiileDetials.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminViewUserProfiileDetials.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminViewUserProfiileDetials.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminViewUserProfiileDetials.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminViewUserProfiileDetials().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnBack;
    private javax.swing.JLabel LbDose1Type;
    private javax.swing.JLabel LblAdd;
    private javax.swing.JLabel LblAge;
    private javax.swing.JLabel LblCountry;
    private javax.swing.JLabel LblDOB;
    private javax.swing.JLabel LblDOse2;
    private javax.swing.JLabel LblDose1;
    private javax.swing.JLabel LblDose2Type;
    private javax.swing.JLabel LblPN;
    private javax.swing.JLabel LblResgister;
    private javax.swing.JLabel LblState;
    private javax.swing.JLabel LblUIC;
    private javax.swing.JLabel LblUName;
    private javax.swing.JTextField TxtAdd;
    private javax.swing.JTextField TxtAge;
    private javax.swing.JTextField TxtCountry;
    private javax.swing.JTextField TxtDOB;
    private javax.swing.JTextField TxtDose1;
    private javax.swing.JTextField TxtDose1Type;
    private javax.swing.JTextField TxtDose2;
    private javax.swing.JTextField TxtDose2Type;
    private javax.swing.JTextField TxtPN;
    private javax.swing.JTextField TxtState;
    private javax.swing.JTextField TxtUIC;
    private javax.swing.JTextField TxtUN;
    // End of variables declaration//GEN-END:variables
}
