package oodjassignment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;

public class Register {

    
 public String UserID,UserIC,UserName,UserDOB,UserPassword,UserCountry,UserAddress,UserState,UserPhone,Dose1,Dose2;
 public int UserType,UserStatus,UserAge,UserClicked;

 
 public String Delimeter = "@#;";
 public String UserText = "User.txt";

 Register()
 {
 
 }

Register (String UID,String UN,String UIC,int UA,String UPN,String UDOB, String UPass,String UCount,String UAdd,String UState,int UType,int UtSta,String D1,String D2,int UC){
UserID = UID;
UserName = UN;
UserIC = UIC;
UserAge = UA;
UserPhone = UPN;
UserDOB = UDOB;
UserPassword = UPass;
UserCountry = UCount;
UserAddress= UAdd;
UserState = UState;
UserType= UType;
UserStatus = UtSta;
Dose1 = D1;
Dose2 = D2;
UserClicked = UC;
}

public void setDose1 (String D1)
{
        Dose1 = D1;
}
 
  public void setDose2 (String D2)
{
        Dose2 = D2;
}
    public void setUserName (String N)
{
        UserName = N;
}

    public void setUserIC (String IC)
{
        UserIC = IC;
}
    public String GetDose1()
{
    return Dose1;
}
    public String GetDose2()
{
    return Dose2;
}  

    public String GetUserName()
{
    return UserName;
}
    public String GetUserIC()
{
    return UserIC;
}     
public boolean Regist(){
boolean sucess = true;
        
    try{
            FileWriter fw = new FileWriter(UserText,true);
            fw.write( this.UserID +Delimeter+ 
                      this.UserName +Delimeter+ 
                      this.UserIC +Delimeter+ 
                      this.UserAge +Delimeter+ 
                      this.UserPhone +Delimeter+ 
                      this.UserDOB +Delimeter+ 
                      this.UserPassword +Delimeter+ 
                      this.UserCountry +Delimeter+ 
                      this.UserAddress +Delimeter+ 
                      this.UserState +Delimeter+ 
                      this.UserType +Delimeter+ 
                      this.UserStatus +Delimeter+
                      this.Dose1 +Delimeter+ 
                      this.Dose2 +Delimeter+
                      this.UserClicked +Delimeter);
            fw.write(System.getProperty("line.separator"));
            fw.close();
            
            
        } catch (IOException ex) {
            sucess = false;
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
    
            String AppointmentID = URD.unique();
            VaccineAppointment CreateAppointment = new VaccineAppointment (AppointmentID,this.UserID,this.UserName,"","","",0); 
            if(CreateAppointment.RegistAppointment())
            {
                System.out.print("registered");
            }
    return sucess;
}



public boolean Userupdate(){
    boolean sucess = true;
    
    String tempFile = "Temp.txt";
    String currentLine;
    String data[];

    try
    {
        FileWriter fw = new FileWriter(tempFile,true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);
        
        FileReader fr = new FileReader(UserText);
        BufferedReader br =new BufferedReader(fr);
        
        while ((currentLine = br.readLine()) != null) {
            data = currentLine.split(Delimeter);
            if (!(data[0].equals(this.UserID))) {
                pw.println(currentLine);
            } else {
                pw.println(
                        this.UserID +Delimeter+
                                this.UserName +Delimeter+
                                this.UserIC +Delimeter+
                                this.UserAge +Delimeter+
                                this.UserPhone +Delimeter+
                                this.UserDOB +Delimeter+
                                this.UserPassword +Delimeter+
                                this.UserCountry +Delimeter+
                                this.UserAddress +Delimeter+
                                this.UserState +Delimeter+
                                this.UserType +Delimeter+
                                this.UserStatus +Delimeter+
                                this.Dose1 +Delimeter+
                                this.Dose2 +Delimeter+
                                this.UserClicked +Delimeter
                );
            }
        }
        pw.flush();
        fr.close();
        br.close();
        fw.close();
        pw.close();
        bw.close();
        
    }
    catch (FileNotFoundException ex) {
        JOptionPane.showMessageDialog(null, "Error Occurred");
        
    }   catch (IOException ex) {
        java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        sucess = false;
    }
    File oldFile = new File (UserText);
    File newFile = new File (tempFile);
    System.out.println(oldFile.exists());
    if (oldFile.delete()) {
        System.out.println("Deleted the file: " + oldFile.getName());
    } else {
        System.out.println("Failed to delete the file.");
    }
    newFile.renameTo(new File(UserText));
    
return sucess;
}

public boolean RegistCenter(){
boolean sucess = true;
        
    try{
            FileWriter fw = new FileWriter(UserText,true);
            fw.write( this.UserID +Delimeter+ 
                      this.UserName +Delimeter+ 
                      this.UserIC +Delimeter+ 
                      this.UserAge +Delimeter+ 
                      this.UserPhone +Delimeter+ 
                      this.UserDOB +Delimeter+ 
                      this.UserPassword +Delimeter+ 
                      this.UserCountry +Delimeter+ 
                      this.UserAddress +Delimeter+ 
                      this.UserState +Delimeter+ 
                      this.UserType +Delimeter+ 
                      this.UserStatus +Delimeter+
                      this.Dose1 +Delimeter+ 
                      this.Dose2 +Delimeter+
                      this.UserClicked +Delimeter);
            fw.write(System.getProperty("line.separator"));
            fw.close();
            
            
        } catch (IOException ex) {
            sucess = false;
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
    
    return sucess;
}

public boolean ReRegistVaccineAppointment(){
boolean sucess = true;
        
    String tempFile = "Temp.txt";
    String currentLine;
    String data[];
    String AppointmentID = URD.unique();


    try
    {
        FileWriter fw = new FileWriter(tempFile,true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter pw = new PrintWriter(bw);
        
        FileReader fr = new FileReader(UserText);
        BufferedReader br =new BufferedReader(fr);
        
        while ((currentLine = br.readLine()) != null) {
            data = currentLine.split(Delimeter);
            if (!(data[0].equals(this.UserID))) {
                pw.println(currentLine);
            } else {
                pw.println(
                        this.UserID +Delimeter+
                                this.UserName +Delimeter+
                                this.UserIC +Delimeter+
                                this.UserAge +Delimeter+
                                this.UserPhone +Delimeter+
                                this.UserDOB +Delimeter+
                                this.UserPassword +Delimeter+
                                this.UserCountry +Delimeter+
                                this.UserAddress +Delimeter+
                                this.UserState +Delimeter+
                                this.UserType +Delimeter+
                                this.UserStatus +Delimeter+
                                this.Dose1 + Delimeter+
                                this.Dose2 +Delimeter+
                                this.UserClicked +Delimeter
                );
            }
        }
        pw.flush();
        fr.close();
        br.close();
        fw.close();
        pw.close();
        bw.close();
        
    }
    catch (FileNotFoundException ex) {
        JOptionPane.showMessageDialog(null, "Error Occurred");
        
    }   catch (IOException ex) {
        java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        sucess = false;
    }
    File oldFile = new File (UserText);
    File newFile = new File (tempFile);
    System.out.println(oldFile.exists());
    if (oldFile.delete()) {
        System.out.println("Deleted the file: " + oldFile.getName());
    } else {
        System.out.println("Failed to delete the file.");
    }
    newFile.renameTo(new File(UserText));
    
            VaccineAppointment CreateAppointment = new VaccineAppointment (AppointmentID,this.UserID,this.UserName,"","","",0); 
            if(CreateAppointment.RegistAppointment())
            {
                System.out.print("registered");
            }
    return sucess;
}


public boolean ONspotRegist(){
boolean sucess = true;
        
    try{
            FileWriter fw = new FileWriter(UserText,true);
            fw.write( this.UserID +Delimeter+ 
                      this.UserName +Delimeter+ 
                      this.UserIC +Delimeter+ 
                      this.UserAge +Delimeter+ 
                      this.UserPhone +Delimeter+ 
                      this.UserDOB +Delimeter+ 
                      this.UserPassword +Delimeter+ 
                      this.UserCountry +Delimeter+ 
                      this.UserAddress +Delimeter+ 
                      this.UserState +Delimeter+ 
                      this.UserType +Delimeter+ 
                      this.UserStatus +Delimeter+
                      this.Dose1 +Delimeter+ 
                      this.Dose2 +Delimeter+
                      this.UserClicked +Delimeter);
            fw.write(System.getProperty("line.separator"));
            fw.close();
            
            
        } catch (IOException ex) {
            sucess = false;
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
    return sucess;
}


public boolean DeleteVaccineCenter(){
boolean sucess = true;

                
                String tempFile = "Temp.txt";
                String currentLine;
                String data[];
                try
                {
                    FileWriter fw = new FileWriter(tempFile,true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter pw = new PrintWriter(bw);
                    
                    FileReader fr = new FileReader(UserText);
                    BufferedReader br =new BufferedReader(fr);
                    
                    while((currentLine = br.readLine())!= null)
                    
                    {
                    data = currentLine.split(Delimeter);
                    if(!(data[0].equalsIgnoreCase(this.UserID)))
                    {
                        pw.println(currentLine);
                    }
                    }
                    pw.flush();
                    fr.close();
                    br.close();
                    fw.close();
                    pw.close();
                    bw.close();
   
                }
                catch (FileNotFoundException ex) {
           JOptionPane.showMessageDialog(null, "Error Occurred");
                
            }   catch (IOException ex) {
                    java.util.logging.Logger.getLogger(AdminCenter.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }
                File oldFile = new File (UserText);
                File newFile = new File (tempFile);
            System.out.println(oldFile.exists());
                    if (oldFile.delete()) { 
                System.out.println("Deleted the file: " + oldFile.getName());
                } else {
                System.out.println("Failed to delete the file.");
                    }
                    
                   newFile.renameTo(new File(UserText));
            
    
    return sucess;
}
}
