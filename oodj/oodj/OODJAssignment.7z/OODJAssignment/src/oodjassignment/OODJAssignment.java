/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oodjassignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Kriso
 */

public class OODJAssignment {
 public String Delimeter = "@#;";
 
    /**
     * @param args the command line arguments
     */
 
    public static void main(String[] args) {
        // TODO code application logic here
        
//      List<VaccineAppointment> bookingList = new ArrayList<VaccineAppointment>();
//           boolean available=true;
//           try{
//               
//            String newAppointmentID ="";
//            File Flist = new File("products.txt");         
//            Scanner sc1 = new Scanner(Flist);
//            
//           newAppointmentID = URD.unique();
//            
//            while(sc1.hasNextLine())
//                {
//                        String Line = sc1.nextLine();
//
//                        while(true){
//                        Random rand = new Random();
//                        int maxNumber = 11;
//                        int randomNumber = rand.nextInt(maxNumber) + 1;
//                        String AppointmentID = "VA"+randomNumber;
//                        String[] wordsinLine = Line.split("@#;");
//                        bookingList.add(new VaccineAppointment(wordsinLine[0],wordsinLine[1],wordsinLine[2],wordsinLine[3],wordsinLine[4],wordsinLine[5],wordsinLine[6]));
//                        boolean work = false;
//
//                        for (int i = 0; i  < bookingList.size(); i++) {
//
//                    if(bookingList.get(i).GetID().equals(AppointmentID)){
//                        work = true;
//                        break;
//                    }
//                    }
//                       newAppointmentID = AppointmentID;
//                       if(work == false){
//                       break;
//                       }
//                }
//            }
//            System.out.print(newAppointmentID);
//
//            sc1.close();
//        
//     }catch (FileNotFoundException ex) {
//           JOptionPane.showMessageDialog(null, "Error Occurred");  
//                }




     
//     List<String> CenterList = new ArrayList<String>();
//        boolean available=true;
//        
//            try{
//                
//                File Flist = new File("VaccineCenter.txt");         
//                Scanner sc1 = new Scanner(Flist);
//            
//                    while(sc1.hasNextLine()){
//               
//                    String Line = sc1.nextLine();
//                    String[] wordsinLine = Line.split("@#;");
//               
//                    CenterList.add(wordsinLine[0]);
//                
//            }
//            if(available){
//            System.out.println(CenterList);
//            }
//            sc1.close();
//        
//            }catch (FileNotFoundException ex) {
//           JOptionPane.showMessageDialog(null, "Error Occurred");  
//                }

//
//try{                        
//                        String AppointmentID = "test"; 
//                        String UserID = "passport";
//                      String Dose2 = "0";
//                        File Flist = new File("User.txt");
//                        Scanner sc1 = new Scanner(Flist);
//                        while(sc1.hasNextLine()){
//                            String Line = sc1.nextLine();
//                            if(Line.contains(UserID)){
//                                String[] wordsinLine = Line.split("@#;");
//                                Register Create = new Register(wordsinLine[0],wordsinLine[1],wordsinLine[2],Integer.parseInt(wordsinLine[3]),wordsinLine[4],wordsinLine[5],wordsinLine[6],wordsinLine[7],wordsinLine[8],wordsinLine[9],Integer.parseInt(wordsinLine[10]),1,AppointmentID,Dose2);
//                                
//                                
//                                System.out.println(wordsinLine[0]+" "+wordsinLine[1]+" "+wordsinLine[2]+" "+Integer.parseInt(wordsinLine[3])+" "+wordsinLine[4]+" "+wordsinLine[5]+" "+wordsinLine[6]+" "+wordsinLine[7]+" "+wordsinLine[8]+" "+wordsinLine[9]+" "+Integer.parseInt(wordsinLine[10])+" "+1+" "+AppointmentID+" "+Dose2);
//                                
//                            }
//                        } sc1.close();
//
//                    } catch (FileNotFoundException ex) {
//                        JOptionPane.showMessageDialog(null, "Error Occurred");
//                    }


//try{
//                      String Dose2 = "";
//                        File Flist = new File("User.txt");
//                        Scanner sc1 = new Scanner(Flist);
//                        while(sc1.hasNextLine()){
//                            String r =  sc1.next();
//
//                            String Line = sc1.nextLine();
//
//                            if(!Line.isEmpty()){
//                               
//                                System.out.println(Line);
//
//                                System.out.println(r);
//                              
//
//                                sc1.close();
////                                if(update.appointmentupdate())
////                                {
////                                    JOptionPane.showMessageDialog(null, "Request User to Respone");
////                                }
//                                break;
//                            }
//                        }
//
//                    } catch (FileNotFoundException ex) {
//                        JOptionPane.showMessageDialog(null, "Error Occurred");
//                    }



        int counter = 0;
        int i = 0;
        for (i = 0; i <= 3; i++) {
            
        while (i < 3) {
            
          Scanner s = new Scanner(System.in);
          
          System.out.println("KIndly enter your name here:");
          String au = s.nextLine();
          String ap = s.nextLine();
           
 
            String pass = "111";
            String user = "zsa";
 
            if (user.equals(au) && (pass.equals(ap))) {
                JOptionPane.showMessageDialog(null, "Successfully log in!");
                return;
 
            }
 
            if (user != (au) && (pass.equals(ap))) {
                JOptionPane.showMessageDialog(null, "Invalid User No", "LOG IN", JOptionPane.ERROR_MESSAGE);
                counter += 1;
                System.out.println(counter);
 
            }
 
            else if (user.equals(au) && (pass != (ap))) {
                JOptionPane.showMessageDialog(null, "Invalid Password", "LOG IN", JOptionPane.ERROR_MESSAGE);
                counter++;
                System.out.println(counter);
 
            }
 
 
                JOptionPane.showMessageDialog(null, "You Inputed 3 wrong password/Username", "LOG IN", JOptionPane.ERROR_MESSAGE);
 
                System.exit(0);
            }
 
        }
}
}
