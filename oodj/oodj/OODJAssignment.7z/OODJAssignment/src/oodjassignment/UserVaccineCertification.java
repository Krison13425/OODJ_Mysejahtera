/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oodjassignment;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 *
 * @author Kriso
 */
public class UserVaccineCertification extends javax.swing.JFrame {

    /**
     * Creates new form UserVaccineCertification
     */
    public String UserID;
    public String Dose1;
    public String Dose2;
    public String Text = "User.txt";
    public String Text1 = "VaccineAppointment.txt";
    public String Text2 = "VaccineCenter.txt";
    public String Text3 = "SuppliedVaccineHistory.txt";
    public String Delimeter = "@#;";
    public UserVaccineCertification() {

    }
    UserVaccineCertification(String UID)
    {
        initComponents();
        this.UserID = UID;
        int AppointmentStatus = 0;
        int AppointmentStatus2 = 0;
        String UserName = null;
        
        try {
            File Flist = new File(Text);
            Scanner sc1 = new Scanner(Flist);
            while (sc1.hasNextLine()) {
                String Line = sc1.nextLine();
                if (Line.contains(UserID)) {
                    String[] wordsinLine = Line.split(Delimeter);
                    UserName = wordsinLine[1];
                    Dose1 = wordsinLine[12];
                    Dose2 = wordsinLine[13];
                    AppointmentStatus = Integer.parseInt(wordsinLine[11]);
                }
            }
            sc1.close();
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error Occurred");
        }
        
        
        String CenterName = null;
        String CenterAddress = null;
        String CenterID = null;
        String Dose = null;
        String DoseDate = null;
        String VaccineBatchNumber = null;
        String CenterName2 = null;
        String CenterID2 = null;
        String DoseType2 = null;
        String DoseDate2 = null;
        String VaccineBatchNumber2 = null;
        
        
        if (!Dose1.equals("null") && Dose2.equals("null")) {
            try {
                File Flist = new File(Text1);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(Dose1)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        CenterID = wordsinLine[3];
                        Dose = wordsinLine[4];
                        DoseDate = wordsinLine[5];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
            try {
                File Flist = new File(Text2);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(CenterID)&&Line.contains(DoseDate)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        CenterName = wordsinLine[1];
                        CenterAddress = wordsinLine[2];
                         if(wordsinLine[5].equals("null")){
                        VaccineBatchNumber = "null";
                        }
                        else
                        {
                        VaccineBatchNumber = wordsinLine[5];
                        }
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
            if(VaccineBatchNumber.equals("null"))
            {
            try {
                File Flist = new File(Text3);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(CenterID)&&Line.contains(DoseDate)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        CenterName = wordsinLine[1];
                        CenterAddress = wordsinLine[2];
                        VaccineBatchNumber = wordsinLine[5];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
            }

            UserView Cert = new UserView();
            Cert.setAddress(CenterAddress);
            Cert.setCenterName(CenterName);
            Cert.setDose(Dose);
            Cert.setDoseDate(DoseDate);
            Cert.setDose1(Dose1);
            Cert.setDose2(Dose2);
            Cert.setAppointmentStatus(AppointmentStatus);
            Cert.setVaccineBatchNumber(VaccineBatchNumber);
            Cert.setUserName(UserName);
            Cert.setUserIC(UID);

            Cert.ViewVaccineCertification(JTxtVC);

            
        }else if (!Dose1.equals("null") && !Dose2.equals("null")) {
            try {
                File Flist = new File(Text1);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(Dose1)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        CenterID = wordsinLine[3];
                        Dose = wordsinLine[4];
                        DoseDate = wordsinLine[5];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
            try {
                File Flist = new File(Text2);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(CenterID)&&Line.contains(DoseDate)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        CenterName = wordsinLine[1];
                        CenterAddress = wordsinLine[2];
                        if(wordsinLine[5].equals("null")){
                        VaccineBatchNumber = "null";
                        }
                        else
                        {
                        VaccineBatchNumber = wordsinLine[5];
                        }
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
            if(VaccineBatchNumber.equals("null"))
            {
            try {
                File Flist = new File(Text3);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(CenterID)&&Line.contains(DoseDate)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        CenterName = wordsinLine[1];
                        VaccineBatchNumber = wordsinLine[5];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
            }
            
            try {
                File Flist = new File(Text1);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(Dose2)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        CenterID2 = wordsinLine[3];
                        DoseType2 = wordsinLine[4];
                        DoseDate2 = wordsinLine[5];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
            try {
                File Flist = new File(Text2);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(CenterID2)&&Line.contains(DoseDate2)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        CenterName2 = wordsinLine[1];
                        if(wordsinLine[5].equals("null")){
                        VaccineBatchNumber2 = "null";
                        }
                        else
                        {
                        VaccineBatchNumber2 = wordsinLine[5];
                        }
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
            if(VaccineBatchNumber2.equals("null"))
            {
            try {
                File Flist = new File(Text3);
                Scanner sc1 = new Scanner(Flist);
                while (sc1.hasNextLine()) {
                    String Line = sc1.nextLine();
                    if (Line.contains(CenterID)&&Line.contains(DoseDate)) {
                        String[] wordsinLine = Line.split(Delimeter);
                        CenterName2 = wordsinLine[1];
                        VaccineBatchNumber2 = wordsinLine[5];
                    }
                }
                sc1.close();
            } catch (FileNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Error Occurred");
            }
            }
            
            System.out.println(AppointmentStatus);
            UserView Cert = new UserView();
            Cert.setUserName(UserName);
            Cert.setUserIC(UID);
            Cert.setDose1(Dose1);
            Cert.setDose2(Dose2);
            Cert.setAppointmentStatus(AppointmentStatus);
            
            Cert.setDose(Dose);
            Cert.setCenterName(CenterName);
            Cert.setDoseDate(DoseDate);
            Cert.setVaccineBatchNumber(VaccineBatchNumber);

            Cert.setCenterName2(CenterName2);
            Cert.setDoseType2(DoseType2);
            Cert.setDoseDate2(DoseDate2);
            Cert.setVaccineBatchNumber2(VaccineBatchNumber2);

            Cert.ViewVaccineCertification(JTxtVC);

            
        }
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        JTxtVC = new javax.swing.JTextArea();
        LblVaccineCertification = new javax.swing.JLabel();
        BtnBack = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        JTxtVC.setColumns(20);
        JTxtVC.setRows(5);
        jScrollPane1.setViewportView(JTxtVC);

        LblVaccineCertification.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        LblVaccineCertification.setText("Vaccine Certification");

        BtnBack.setText("Back");
        BtnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(BtnBack)
                        .addGap(58, 58, 58)
                        .addComponent(LblVaccineCertification)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(33, Short.MAX_VALUE)
                        .addComponent(LblVaccineCertification)
                        .addGap(18, 18, 18))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(BtnBack)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBackActionPerformed
        this.setVisible(false);
        new UserProfile(UserID).setVisible(true);
    }//GEN-LAST:event_BtnBackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserVaccineCertification.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserVaccineCertification.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserVaccineCertification.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserVaccineCertification.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserVaccineCertification().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnBack;
    private javax.swing.JTextArea JTxtVC;
    private javax.swing.JLabel LblVaccineCertification;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

    private void ViewVaccineCertification(JTextArea JTxtVC) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
